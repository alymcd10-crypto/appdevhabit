# Contact Verifier — v1.1 Upgrade Notes

This patch is targeted at the **SerpAPI-only deployment** path: you have a
SerpAPI key, but no PDL / Hunter / RapidAPI keys (or you're holding off until
you've validated the system works).

## What changed (and why it matters for SerpAPI-only)

### 1. SerpAPI source — major rewrite (`sources/serpapi.js`)

**Stopped excluding Realtor.com / Zillow / Avvo from website detection.**
v1's `parseOrganic` line 27 silently dropped `realtor.com|zillow` results from
`websiteUrl` candidacy. For realtors specifically, those agent-profile pages
are the **single best public data source** — they expose current company,
license, photo, phone, listings as structured data. v1 was throwing them away.
v1.1 captures them as `profileUrls.realtor` / `profileUrls.zillow` /
`profileUrls.avvo` and routes them to `website.js` for site-aware scraping.

**Added Google Maps engine.** Previously v1 read `local_results` from a
generic web search — sparse, sometimes missing. v1.1 fires a dedicated
`engine=google_maps` call (one extra search per contact, only when a company
hint exists) which returns title, phone, full address, website, photo,
rating, review count. Roughly 5× the structured signal per call.

**LinkedIn snippet parsing.** Without a RapidAPI key, v1 captured the
LinkedIn URL but ignored the snippet text. SerpAPI snippets contain
`Name - Title at Company - City, State - 500+ connections`. v1.1 parses
title/company/headline/address out of these. Effectively a free LinkedIn
data source for the cases where the snippet has the data.

**`engine=google_maps` + `headshot` keyword on image search**, only fired
when no photo was found yet (saves a search call when KG/website already
gave us one).

**Usage tracking.** `getUsage()` returns `{ searches, errors }`. Surfaced
at `GET /api/health` so you can watch your SerpAPI burn rate live.

**429 retry with backoff.** One retry on rate-limit — useful at higher
batch concurrency.

---

### 2. Website source — site-aware scrapers (`sources/website.js`)

Now returns an **array** of per-origin results instead of a single merged
record:

- `realtor_com` — uses Realtor.com's structured selectors (`data-testid`
  attributes, `og:image`, `tel:` link).
- `zillow` — parses the JSON-LD blob Zillow embeds for agent profiles
  (Person schema with `jobTitle`, `worksFor`, `telephone`, `image`).
- `avvo` — Avvo lawyer profile selectors (`data-testid="lawyer-headline"`,
  firm name, phone).
- `website` — generic firm-website scrape, now also tries `/our-team`,
  `/agents/<slug>`, `/attorneys/<slug>`, `/people/<slug>`.

This is the change that matters most for confidence scores — see (4).

---

### 3. emailGuess source — Hunter alternative (`sources/emailGuess.js`)

When you don't have Hunter ($49/mo for 500 lookups), this generates the 8
most common B2B email patterns from name + domain, then verifies them in **a
single SerpAPI call** using OR'd quoted candidates. Patterns the public web
already echoes are returned as confirmed emails.

Patterns generated (in order, by industry frequency):

```
jane.doe@firm.com   ← dominant for ~60% of US firms
jane@firm.com       ← small practices
jdoe@firm.com       ← corporate
janedoe@firm.com
jane_doe@firm.com
jane.d@firm.com
doe.jane@firm.com
doej@firm.com
```

Free-mail domains (gmail, yahoo, icloud, etc.) are skipped — pattern
guessing is meaningless against them.

Confidence design:
- Verified hit (pattern appears in public web) → trust 80, lands in auto-update
  if **also** confirmed by website scrape.
- Unverified top guess → trust 50, drops below the manual-review floor.

So bad guesses don't get surfaced. Top picks need a second source to pass.

Costs **one SerpAPI search per contact** when active. Skip with `SERPAPI_KEY=`
unset (then this source skips itself).

---

### 4. Aggregator — dynamic trust + per-origin sources (`aggregator.js`)

**Dynamic trust rebalancing.** When none of the paid sources (PDL/Hunter/
LinkedIn) have keys configured, SerpAPI's per-field trust gets +10 and the
canonical free profile sources (Realtor.com, Zillow, Avvo) get +5. This
matters because the auto-update threshold is 95 — without a boost, SerpAPI
(trust 60-70) + one supporting source rarely cleared the bar. With the
boost, SerpAPI(80) + realtor_com(93) on the same field → 99, auto-update.

**Agreement now uses `max(trust1, trust2) + boost`** instead of `trust1 +
boost`. The v1 logic gave weird results when a low-trust source landed
first and a high-trust source agreed second: you got the LOW source's
score plus the boost, strictly worse than the high source alone. Fixed.

**Per-origin website results.** Realtor.com, Zillow, Avvo, and the generic
firm website are now four independent sources for cross-source agreement
math. Previously v1's `website.js` collapsed everything into one
`{source: 'website'}` blob, so you lost the agreement bonus.

**emailGuess verification boost.** When emailGuess returns
`_candidatesVerified.length > 0`, its email trust jumps from 50 to 80.

**Changes audit now includes all contributing sources**, not just the first.

---

### 5. verify.js — wires the new sources

```
Phase 1:  pdl, serpapi                                     (parallel)
Phase 2:  linkedin, hunter, emailGuess, website            (parallel, depend on Phase 1)
Phase 3:  gravatar (uses any email found)
```

`profileUrls` from SerpAPI is forwarded to `website.lookup()` so it knows
which Realtor/Zillow/Avvo pages to scrape.

---

### 6. routes.js — `/api/health` exposes SerpAPI usage

```json
{
  "ok": true,
  "sources": { "serpapi": true, "hunter": false, ... },
  "usage": { "serpapi": { "searches": 1247, "errors": 3 } },
  "cache": { "total": 412 }
}
```

Watch this during a batch run to confirm you're not blowing through your
plan. With v1.1, expected SerpAPI cost per contact:

- 2 searches when no company is provided (main + linkedin)
- 3 searches with a company (main + linkedin + maps)
- 4 if no photo surfaced (above + image search)
- 5 if emailGuess is active (above + verification search)

For 8,000 contacts at the worst case (5 searches each) = 40,000 searches.
At SerpAPI's $50/5k tier that's $400. The 30-day cache (already in v1)
means re-runs cost ~$0 except for changed contacts.

---

## Files changed

```
server/
  sources/
    serpapi.js     ← rewritten (new: Maps engine, profile capture, snippet parse, usage)
    website.js     ← rewritten (new: site-aware scrapers; returns array)
    emailGuess.js  ← NEW
  util.js          ← +domainOf(); expanded role-email blacklist in extractEmails
  aggregator.js    ← dynamic trust + max-trust agreement + per-origin handling
  verify.js        ← wires emailGuess + profileUrls forwarding + sourceUsage()
  routes.js        ← /health exposes usage
```

No frontend changes required — `app.jsx` already reads `verified`,
`confidence`, `sources`, `autoUpdate`, `manualReview`, `fieldAudit`,
`changes`, all unchanged in shape.

No new npm dependencies. No `package.json` changes.

---

## Testing checklist

1. **Drop in the files**, restart the server. `GET /api/health` should now
   show 7 sources (the new `emailGuess` row).

2. **Single test run** with a known realtor:
   ```
   curl -X POST http://localhost:3001/api/verify \
     -H 'Content-Type: application/json' \
     -d '{"contact":{"name":"Sarah Johnson","type":"realtor","company":"Compass Chicago"}}'
   ```
   In `sources` you should see `serpapi`, `realtor_com` (or `zillow`),
   `website`, `gravatar` — and `emailGuess` if SerpAPI surfaced a website.

3. **Check usage** with `GET /api/health`. Expect ~3-5 searches consumed
   per single-contact run.

4. **Confidence sanity:** for a known active realtor, `autoUpdate` should
   include at least `phone` and `company` (previously hard to reach without
   PDL).

5. **Free-tier ceiling:** at 100 SerpAPI searches/month, you get ~25-30
   contacts verified before hitting the cap. The cache means subsequent
   runs of the same contacts are free. For real bulk work, the $50/5k
   tier is the floor.

---

## What I deliberately did NOT change

- **Cache logic.** Still keyed by `(name, company)`. If you want to bust
  cache on the new code path, either change `cacheKey()` to include a
  version suffix or just `DELETE FROM verifications` once.
- **Auth, webhooks, rate-limit per user.** Out of scope for this patch.
- **License-board verification** (NAR / IL IDFPR / IL IARDC). Would need
  state-by-state HTTP scrapers — happy to add as a Phase 2 source if you
  want, but it's an afternoon's work per state and the data is mostly
  duplicative of what Realtor.com / Avvo already give you.
- **Zillow & Realtor.com scrapers are best-effort.** Both sites change DOM
  occasionally; the JSON-LD path on Zillow is the most resilient. If a
  selector goes stale you'll see those sources go quiet but the rest of
  the pipeline continues.
