// server/aggregator.js — merge source results into a single verified record.
//
// CHANGES vs v1:
//   1. Each website-derived origin (realtor_com, zillow, avvo, website) is
//      treated as an INDEPENDENT source for cross-source agreement.
//   2. Dynamic trust rebalancing — when paid sources are absent (no PDL/
//      Hunter/LinkedIn key), SerpAPI and free sources get a boost so that
//      a SerpAPI + website agreement can still cross the auto-update bar.
//   3. emailGuess source added with low trust, boosted high when verified.
//   4. profileUrls passed through to final.profileUrls (not aggregated).
//
// Confidence rubric:
//   95+   → auto-update
//   70-94 → manual review
//   <70   → dropped
import { normalizePhone, normalizeEmail, normalizeName } from './util.js';

const FREE_EMAIL_DOMAINS = ['gmail.com','yahoo.com','hotmail.com','outlook.com','aol.com','icloud.com','me.com'];

// Per-source, per-field trust weights. Higher = more trusted.
// IMPORTANT: realtor_com and zillow are treated as independent of generic
// 'website' so the boost-for-agreement bonus actually fires.
const TRUST_BASE = {
  linkedin:   { title: 95, company: 90, photoUrl: 95, address: 60, headline: 90 },
  pdl:        { email: 85, phone: 80, company: 80, title: 80, address: 70, linkedinUrl: 85 },
  hunter:     { email: 85, title: 60, phone: 55, linkedinUrl: 70 },
  serpapi:    { phone: 70, email: 65, company: 60, title: 60, address: 75, websiteUrl: 90, linkedinUrl: 85, photoUrl: 65, headline: 70 },
  website:    { phone: 75, email: 80, photoUrl: 75 },
  realtor_com:{ phone: 88, company: 88, title: 80, address: 80, photoUrl: 85 },  // canonical for realtors
  zillow:     { phone: 85, company: 85, title: 75, address: 75, photoUrl: 80 },
  avvo:       { phone: 85, company: 85, title: 80, address: 75, photoUrl: 80 },  // canonical for lawyers
  emailGuess: { email: 50 }, // boosted to 80 when verified hit (see below)
  gravatar:   { photoUrl: 70 },
};

const BOOST_AGREE = 20;        // two sources agree → add this
const PENALTY_CONFLICT = 15;   // sources disagree → subtract
const AUTO_UPDATE_THRESHOLD = 95;
const MANUAL_REVIEW_THRESHOLD = 70;

// When the canonical paid sources aren't in play, redistribute their weight
// onto the free/SerpAPI ones so a 2-source agreement can still cross 95.
function buildTrust(activeSources) {
  const trust = JSON.parse(JSON.stringify(TRUST_BASE));
  const hasPaid = activeSources.has('pdl') || activeSources.has('linkedin') || activeSources.has('hunter');
  if (!hasPaid) {
    // SerpAPI becomes the "anchor" — bump its scores so it lands in the
    // 70–84 band where one supporting source pushes it to auto-update.
    for (const f of ['phone', 'email', 'company', 'title', 'address']) {
      if (trust.serpapi[f] != null) trust.serpapi[f] = Math.min(85, trust.serpapi[f] + 10);
    }
    // Realtor.com / Zillow / Avvo are canonical free sources — lift them too.
    for (const src of ['realtor_com', 'zillow', 'avvo']) {
      for (const f of Object.keys(trust[src])) trust[src][f] = Math.min(92, trust[src][f] + 5);
    }
  }
  return trust;
}

function normEq(field, a, b) {
  if (a == null || b == null) return false;
  if (field === 'phone') return normalizePhone(a).replace(/^\+?1/, '') === normalizePhone(b).replace(/^\+?1/, '');
  if (field === 'email') return normalizeEmail(a) === normalizeEmail(b);
  if (field === 'company' || field === 'title') {
    const A = normalizeName(a), B = normalizeName(b);
    if (!A || !B) return false;
    const n = Math.min(A.length, B.length, 8);
    return A.slice(0, n) === B.slice(0, n) || A.includes(B.slice(0, n)) || B.includes(A.slice(0, n));
  }
  if (field === 'address') {
    return normalizeName(a).slice(0, 10) === normalizeName(b).slice(0, 10);
  }
  return String(a).toLowerCase() === String(b).toLowerCase();
}

/**
 * results: Array<{source, ...fields}>  — raw per-source outputs (may include nested arrays)
 * original: the input contact (name, company, phone, email, address)
 */
export function aggregate(original, resultsRaw) {
  // Flatten — website source now returns an array of per-origin records.
  const results = [];
  for (const r of (resultsRaw || [])) {
    if (Array.isArray(r)) results.push(...r);
    else if (r) results.push(r);
  }

  // Determine which sources actually contributed data, then build trust dynamically.
  const activeSources = new Set(results.filter(r => r && !r.skipped).map(r => r.source));
  const TRUST = buildTrust(activeSources);

  // Apply emailGuess verification boost: if it has _candidatesVerified, raise its email trust.
  for (const r of results) {
    if (r?.source === 'emailGuess' && r._candidatesVerified?.length) {
      TRUST.emailGuess = { ...TRUST.emailGuess, email: 80 };
      break;
    }
  }

  const FIELDS = ['email', 'phone', 'company', 'title', 'address', 'linkedinUrl', 'photoUrl', 'websiteUrl'];
  const final = {};
  const fieldAudit = {};
  const changes = [];
  const autoUpdate = [];
  const manualReview = [];

  for (const field of FIELDS) {
    const candidates = new Map();
    for (const r of results) {
      const v = r?.[field];
      if (!v || r.skipped) continue;
      const trust = TRUST[r.source]?.[field];
      if (trust == null) continue;

      let matched = null;
      for (const c of candidates.values()) {
        if (normEq(field, c.value, v)) { matched = c; break; }
      }
      if (matched) {
        // Take the higher of the two trusts as the floor, then add the agreement bonus.
        // Without this, a low-trust serpapi result followed by a high-trust realtor_com
        // result yielded serpapi's score + boost — strictly worse than realtor_com alone.
        matched.confidence = Math.min(99, Math.max(matched.confidence, trust) + BOOST_AGREE);
        if (!matched.sources.includes(r.source)) matched.sources.push(r.source);
      } else {
        candidates.set(`${r.source}:${v}`, { value: v, confidence: trust, sources: [r.source] });
      }
    }

    if (!candidates.size) continue;

    const ranked = [...candidates.values()].sort((a, b) => b.confidence - a.confidence);
    if (ranked.length >= 2) ranked[0].confidence = Math.max(0, ranked[0].confidence - PENALTY_CONFLICT);

    const winner = ranked[0];
    final[field] = winner.value;
    fieldAudit[field] = winner;

    const origVal = original?.[field === 'linkedinUrl' || field === 'websiteUrl' || field === 'photoUrl' ? '__skip__' : field];
    if (origVal && !normEq(field, origVal, winner.value)) {
      changes.push({ field, from: origVal, to: winner.value, source: winner.sources[0], sources: winner.sources, confidence: winner.confidence });
    }

    if (winner.confidence >= AUTO_UPDATE_THRESHOLD) autoUpdate.push(field);
    else if (winner.confidence >= MANUAL_REVIEW_THRESHOLD) manualReview.push(field);
  }

  // Social profiles — flatten from any source.
  const social = {};
  for (const r of results) {
    if (!r?.socials) continue;
    for (const [k, v] of Object.entries(r.socials)) {
      if (v && !social[k]) social[k] = v;
    }
  }
  if (Object.keys(social).length) final.social = social;

  // Profile URLs — pass through (not aggregated).
  const profileUrls = {};
  for (const r of results) {
    if (!r?.profileUrls) continue;
    for (const [k, v] of Object.entries(r.profileUrls)) {
      if (v && !profileUrls[k]) profileUrls[k] = v;
    }
  }
  if (Object.keys(profileUrls).length) final.profileUrls = profileUrls;

  // Free-email-domain penalty for professionals.
  if (final.email) {
    const domain = final.email.split('@')[1] || '';
    if (FREE_EMAIL_DOMAINS.includes(domain) && fieldAudit.email) {
      fieldAudit.email.confidence = Math.max(0, fieldAudit.email.confidence - 10);
      if (fieldAudit.email.confidence < AUTO_UPDATE_THRESHOLD) {
        // Demote auto-update → manual review.
        const i = autoUpdate.indexOf('email');
        if (i >= 0) { autoUpdate.splice(i, 1); manualReview.push('email'); }
      }
    }
  }

  // Overall verdict.
  const overallConfidence = Math.round(
    Object.values(fieldAudit).reduce((s, c) => s + c.confidence, 0) / Math.max(1, Object.keys(fieldAudit).length),
  );
  let overall = 'not-found';
  if (fieldAudit.company && fieldAudit.company.confidence >= AUTO_UPDATE_THRESHOLD
      && original?.company && !normEq('company', original.company, fieldAudit.company.value)) {
    overall = 'changed';
  } else if (autoUpdate.length >= 2) overall = 'verified';
  else if (autoUpdate.length + manualReview.length >= 2) overall = 'partial';
  else if (Object.keys(fieldAudit).length === 0) overall = 'not-found';
  else overall = 'partial';

  return {
    overall,
    confidence: overallConfidence,
    verified: final,
    original,
    changes,
    sources: [...activeSources],
    autoUpdate,
    manualReview,
    fieldAudit,
    timestamp: new Date().toISOString(),
  };
}
