// server/sources/website.js — server-side website fetch (no CORS restrictions).
//
// CHANGES vs v1:
//   1. Accepts profileUrls hint from SerpAPI and scrapes Realtor.com / Zillow /
//      Avvo profile pages with site-aware selectors. These are the highest-signal
//      free data sources for realtors and lawyers — better than 90% of personal
//      websites — so we fetch them in addition to the main site.
//   2. Returns multiple candidate sources (one per origin) instead of merging
//      everything into a single 'website' result. The aggregator can then treat
//      a Zillow agent profile as an independent source agreeing with serpapi.
//   3. Adds /our-team, /agents/<slug>, /attorneys/<slug> path discovery.
import * as cheerio from 'cheerio';
import { timedFetch, extractEmails, extractPhones } from '../util.js';

export const available = () => true;

async function fetchHtml(url) {
  try {
    const r = await timedFetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; ContactVerifier/1.1; +verifier)' },
      redirect: 'follow',
    }, 9000);
    if (!r.ok) return null;
    const ctype = r.headers.get('content-type') || '';
    if (!/text\/html|application\/xhtml/i.test(ctype)) return null;
    return await r.text();
  } catch { return null; }
}

function absUrl(src, base) {
  if (!src) return null;
  if (src.startsWith('http')) return src;
  if (src.startsWith('//')) return `https:${src}`;
  try { return new URL(src, base).toString(); } catch { return null; }
}

function findPersonPhoto($, name, baseUrl) {
  const [first = '', ...rest] = String(name).trim().split(/\s+/);
  const last = rest.pop() || '';
  if (!first || !last) return null;
  const pat = new RegExp(`${first}[\\s_-]*${last}|${last}[\\s_-]*${first}`, 'i');
  let best = null;
  $('img').each((_, el) => {
    const src = $(el).attr('src') || $(el).attr('data-src') || '';
    const alt = $(el).attr('alt') || '';
    if (pat.test(alt) || pat.test(src)) { best = absUrl(src, baseUrl); return false; }
  });
  return best;
}

// ─── Site-specific scrapers ───────────────────────────────────────
// Each returns a partial source result with whatever it found.

function scrapeRealtorCom($, url) {
  // Realtor.com agent pages: /realestateagents/<slug>
  const out = { source: 'realtor_com', websiteUrl: url, sourceUrl: url };
  out.title = $('[data-testid="agent-bio-title"]').first().text().trim() || null;
  out.company = $('[data-testid="agent-broker-name"]').first().text().trim()
              || $('[itemprop="memberOf"]').first().text().trim()
              || null;
  // Phone: agent pages show as tel:
  const tel = $('a[href^="tel:"]').first().attr('href');
  if (tel) out.phone = tel.replace('tel:', '').trim();
  // Photo (og:image is reliable on realtor.com)
  out.photoUrl = $('meta[property="og:image"]').attr('content') || null;
  // Address
  out.address = $('[data-testid="agent-office-address"]').first().text().trim() || null;
  return out;
}

function scrapeZillow($, url) {
  // Zillow: /profile/<username>/
  const out = { source: 'zillow', websiteUrl: url, sourceUrl: url };
  // Zillow exposes a JSON-LD blob with the profile data; parse it if present.
  const ld = $('script[type="application/ld+json"]').toArray()
    .map(el => { try { return JSON.parse($(el).text()); } catch { return null; } })
    .filter(Boolean);
  for (const j of ld) {
    const obj = Array.isArray(j) ? j[0] : j;
    if (obj?.['@type']?.includes?.('Person') || obj?.['@type'] === 'Person') {
      out.title    = obj.jobTitle || out.title;
      out.company  = obj.worksFor?.name || obj.affiliation?.name || out.company;
      out.phone    = obj.telephone || out.phone;
      out.photoUrl = obj.image || out.photoUrl;
      out.address  = obj.address?.streetAddress
                   || [obj.address?.addressLocality, obj.address?.addressRegion].filter(Boolean).join(', ')
                   || out.address;
    }
  }
  out.photoUrl = out.photoUrl || $('meta[property="og:image"]').attr('content') || null;
  if (!out.title) out.title = $('h1').first().text().trim() || null;
  return out;
}

function scrapeAvvo($, url) {
  // Avvo lawyer pages: /attorneys/<state>/<city>/<slug>.html
  const out = { source: 'avvo', websiteUrl: url, sourceUrl: url };
  out.title    = $('[data-testid="lawyer-headline"]').first().text().trim()
              || $('.lawyer-headline').first().text().trim()
              || 'Attorney';
  out.company  = $('.firm-name, [data-testid="firm-name"]').first().text().trim() || null;
  out.phone    = $('[data-testid="phone-number"]').first().text().trim()
              || ($('a[href^="tel:"]').first().attr('href') || '').replace('tel:', '').trim() || null;
  out.address  = $('[itemprop="address"]').first().text().trim() || null;
  out.photoUrl = $('meta[property="og:image"]').attr('content') || null;
  return out;
}

async function scrapeProfile(kind, url, contact) {
  const html = await fetchHtml(url);
  if (!html) return null;
  const $ = cheerio.load(html);
  let result;
  if (kind === 'realtor')  result = scrapeRealtorCom($, url);
  else if (kind === 'zillow') result = scrapeZillow($, url);
  else if (kind === 'avvo')   result = scrapeAvvo($, url);
  else return null;

  // Common phone/email harvesting on the same page (catches missed cases).
  const text = $('body').text().replace(/\s+/g, ' ');
  if (!result.phone) result.phone = extractPhones(text)[0] || null;
  if (!result.email) result.email = extractEmails(text)[0] || null;
  if (!result.photoUrl) result.photoUrl = findPersonPhoto($, contact.name, url);
  return result;
}

// ─── Generic firm-website scrape ──────────────────────────────────
async function scrapeFirmWebsite(startUrl, contact) {
  const base = startUrl.replace(/\/+$/, '');
  const paths = ['', '/contact', '/about', '/team', '/our-team', '/staff', '/agents', '/attorneys', '/people'];
  const collected = { phones: [], emails: [], photo: null, sourceUrl: null };

  // Quick name-slug guess for common patterns: /agents/jane-doe, /attorneys/jane-doe
  const slug = String(contact.name || '').toLowerCase().trim().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  if (slug) {
    paths.push(`/agents/${slug}`, `/attorneys/${slug}`, `/team/${slug}`, `/our-team/${slug}`, `/people/${slug}`);
  }

  for (const p of paths) {
    const url = /^https?:\/\//.test(base) ? base + p : `https://${base}${p}`;
    const html = await fetchHtml(url);
    if (!html) continue;
    const $ = cheerio.load(html);
    const text = $('body').text().replace(/\s+/g, ' ');
    collected.phones.push(...extractPhones(text));
    collected.emails.push(...extractEmails(text));
    if (!collected.photo) {
      const photo = findPersonPhoto($, contact.name, url);
      if (photo) { collected.photo = photo; collected.sourceUrl = url; }
    }
    if (collected.phones.length && collected.emails.length && collected.photo) break;
  }

  return {
    source: 'website',
    phone: collected.phones[0] || null,
    email: collected.emails[0] || null,
    photoUrl: collected.photo || null,
    websiteUrl: startUrl,
    sourceUrl: collected.sourceUrl || startUrl,
  };
}

// ─── Public lookup — returns ARRAY of source results ──────────────
// Different from v1 (which returned one). Aggregator sees each origin as
// independent, which makes cross-source agreement easier to hit.
export async function lookup(contact, hints = {}) {
  const results = [];
  const profileUrls = hints.profileUrls || {};

  // Site-specific profile scrapes — high signal, run in parallel.
  const profileJobs = [];
  if (profileUrls.realtor) profileJobs.push(scrapeProfile('realtor', profileUrls.realtor, contact));
  if (profileUrls.zillow)  profileJobs.push(scrapeProfile('zillow',  profileUrls.zillow,  contact));
  if (profileUrls.avvo)    profileJobs.push(scrapeProfile('avvo',    profileUrls.avvo,    contact));

  // Generic firm website (only if we have a clean URL).
  if (hints.websiteUrl) {
    profileJobs.push(scrapeFirmWebsite(hints.websiteUrl, contact));
  }

  if (!profileJobs.length) return [{ source: 'website', skipped: 'no-url' }];

  const settled = await Promise.allSettled(profileJobs);
  for (const s of settled) {
    if (s.status === 'fulfilled' && s.value) results.push(s.value);
  }

  return results.length ? results : [{ source: 'website', skipped: 'no-data' }];
}
