// server/sources/emailGuess.js — pattern-based email finder.
//
// Stand-in for Hunter.io when no Hunter key is available. Generates the most
// common B2B email patterns from name + domain, then validates via a SINGLE
// SerpAPI search using OR'd quoted candidates. Any pattern that the public
// web already echoes back is overwhelmingly likely to be real.
//
// Confidence is intentionally moderate (65) — these emails should land in
// "manual review" by default. If the website source ALSO contains the email,
// the aggregator's agreement bonus pushes it over auto-update.
import { timedFetch, normalizeName, sleep } from '../util.js';

const SERPAPI_KEY = process.env.SERPAPI_KEY;
export const available = () => !!SERPAPI_KEY; // we lean on serpapi for verification

// Returns plausible patterns ordered by frequency in real B2B data.
// (Source: aggregated industry surveys; first.last is dominant for 60%+ of
// US firms, single-name patterns dominate among small practices.)
export function generatePatterns(name, domain) {
  if (!name || !domain) return [];
  const parts = String(name).trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (parts.length < 2) return [];
  const first = parts[0].replace(/[^a-z]/g, '');
  const last  = parts[parts.length - 1].replace(/[^a-z]/g, '');
  if (!first || !last) return [];
  const fi = first[0];
  const li = last[0];
  const d  = String(domain).toLowerCase().replace(/^www\./, '').trim();
  const out = [
    `${first}.${last}@${d}`,           //  jane.doe@firm.com  (most common)
    `${first}@${d}`,                   //  jane@firm.com      (small firms)
    `${fi}${last}@${d}`,               //  jdoe@firm.com      (corporate)
    `${first}${last}@${d}`,            //  janedoe@firm.com
    `${first}_${last}@${d}`,           //  jane_doe@firm.com
    `${first}.${li}@${d}`,             //  jane.d@firm.com
    `${last}.${first}@${d}`,           //  doe.jane@firm.com
    `${last}${fi}@${d}`,               //  doej@firm.com
  ];
  return [...new Set(out)];
}

async function serpVerify(candidates) {
  // One search — quoted candidates joined by OR.
  const q = candidates.slice(0, 6).map(e => `"${e}"`).join(' OR ');
  const url = `https://serpapi.com/search.json?q=${encodeURIComponent(q)}&num=10&api_key=${SERPAPI_KEY}`;
  try {
    const r = await timedFetch(url, {}, 12000);
    if (!r.ok) return [];
    const j = await r.json();
    const blob = JSON.stringify(j.organic_results || j).toLowerCase();
    return candidates.filter(e => blob.includes(e.toLowerCase()));
  } catch { return []; }
}

export async function lookup(contact, hints = {}) {
  if (!SERPAPI_KEY) return { source: 'emailGuess', skipped: 'no-key' };
  const domain = hints.websiteDomain
              || (contact.email ? contact.email.split('@')[1] : null);
  if (!domain || !contact.name) return { source: 'emailGuess' };

  // Skip free-mail domains — pattern guessing is meaningless against gmail etc.
  if (/^(gmail|yahoo|hotmail|outlook|aol|icloud|me|mac|protonmail|live|comcast)\.com?$/i.test(domain)) {
    return { source: 'emailGuess', skipped: 'free-mail-domain' };
  }

  const patterns = generatePatterns(contact.name, domain);
  if (!patterns.length) return { source: 'emailGuess' };

  // Verify via single SerpAPI call.
  const verified = await serpVerify(patterns);
  if (verified.length) {
    return {
      source: 'emailGuess',
      email: verified[0],
      _candidatesTried: patterns,
      _candidatesVerified: verified,
    };
  }

  // No verification hit — return top pattern as a low-confidence guess.
  // Aggregator's TRUST table will keep this in "manual review" zone.
  return {
    source: 'emailGuess',
    email: patterns[0],
    _candidatesTried: patterns,
    _verified: false,
  };
}
