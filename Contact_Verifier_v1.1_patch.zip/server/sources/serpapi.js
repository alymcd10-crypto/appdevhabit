// server/sources/serpapi.js — Google Search + Maps + Images via SerpAPI.
// Returns raw hits; the aggregator decides what to trust.
//
// CHANGES vs v1:
//   1. Realtor.com / Zillow / Avvo profile URLs are CAPTURED (not blacklisted).
//      They feed website.js for site-aware scraping.
//   2. Dedicated google_maps engine call when we have a company — much richer
//      than scraping local_results from a generic web search.
//   3. LinkedIn snippets are parsed for "Title at Company · Location · ..."
//      to extract title/company/address even without a RapidAPI key.
//   4. Image search adds "headshot" / "portrait" keywords for better results.
//   5. Usage counter — see getUsage() — so /api/health can show searches consumed.
//   6. 429 retry with backoff (one retry only).
import { timedFetch, extractEmails, extractPhones, sleep } from '../util.js';

const KEY = process.env.SERPAPI_KEY;
export const available = () => !!KEY;

// ─── Usage tracking ───────────────────────────────────────────────
let totalSearches = 0;
let totalErrors = 0;
export function getUsage() { return { searches: totalSearches, errors: totalErrors }; }
export function resetUsage() { totalSearches = 0; totalErrors = 0; }

async function callSerp(params) {
  if (!KEY) return null;
  const qs = new URLSearchParams({ api_key: KEY, ...params });
  const url = `https://serpapi.com/search.json?${qs}`;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      totalSearches++;
      const r = await timedFetch(url, {}, 12000);
      if (r.status === 429) { await sleep(1500); continue; }
      if (!r.ok) { totalErrors++; return null; }
      return await r.json();
    } catch {
      totalErrors++;
      if (attempt === 0) { await sleep(800); continue; }
      return null;
    }
  }
  return null;
}

const search = (q, extra = {}) => callSerp({ q, num: '8', ...extra });
const searchMaps = (q, extra = {}) => callSerp({ engine: 'google_maps', q, type: 'search', ...extra });

// ─── Profile-URL classifiers ──────────────────────────────────────
// These are the "high-signal profile sites" we WANT to capture rather
// than discard. The website source will scrape them with site-aware logic.
const PROFILE_PATTERNS = {
  linkedin: /linkedin\.com\/in\//i,
  realtor:  /realtor\.com\/realestateagents\//i,
  zillow:   /zillow\.com\/profile\//i,
  avvo:     /avvo\.com\/attorneys\//i,        // lawyers
  martindale: /martindale\.com\/[^/]+\/[^/]+\.html/i, // lawyers
  homes:    /homes\.com\/real-estate-agents\//i,
  facebook: /facebook\.com\//i,
  instagram:/instagram\.com\//i,
  twitter:  /twitter\.com\/|x\.com\//i,
  yelp:     /yelp\.com\/biz\//i,
};

// Sites we should NOT treat as the contact's "personal/firm website".
const NON_WEBSITE = /linkedin|facebook|twitter|instagram|x\.com|yelp\.com|google\.com|wikipedia|youtube|tiktok|zillow|realtor\.com|avvo|martindale|homes\.com|yellowpages/i;

function classifyLink(link) {
  for (const [k, re] of Object.entries(PROFILE_PATTERNS)) {
    if (re.test(link)) return k;
  }
  return null;
}

// LinkedIn snippet has the form:
//   "Jane Doe - Senior Realtor at XYZ Realty - Chicago, IL · 500+ connections"
// or similar. We extract the chunk between the name dash and the next pipe/middot.
function parseLinkedinSnippet(title, snippet) {
  const out = { title: null, company: null, headline: null, address: null };
  const fullText = `${title || ''} ${snippet || ''}`;

  // "<Name> - <Title> at <Company>" pattern
  const m = title?.match(/[-–]\s*(.+?)\s+at\s+(.+?)(?:\s*[-–|·]|$)/i);
  if (m) { out.title = m[1].trim(); out.company = m[2].trim(); }

  // City, State (US) — e.g. "Chicago, IL" or "Chicago Metropolitan Area"
  const loc = fullText.match(/\b([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)*),\s*([A-Z]{2})\b/);
  if (loc) out.address = `${loc[1]}, ${loc[2]}`;

  // Headline = whole title chunk before the first " - "
  if (title?.includes(' - ')) out.headline = title.split(' - ')[1]?.split(' | ')[0]?.trim() || null;
  return out;
}

function parseOrganic(results = []) {
  const hits = {
    phones: [], emails: [], websiteUrl: null, headline: null,
    title: null, company: null, address: null,
    profileUrls: {}, // { linkedin, realtor, zillow, avvo, ... }
    socials: {},
  };

  for (const r of results.slice(0, 8)) {
    const title = r.title || '';
    const snippet = r.snippet || '';
    const link = r.link || '';
    if (!link) continue;

    const cls = classifyLink(link);

    // Capture first instance of each profile type.
    if (cls && !hits.profileUrls[cls]) {
      hits.profileUrls[cls] = link;
    }

    // Mirror social profiles into socials object for downstream merge.
    if (cls === 'facebook'   && !hits.socials.facebook)  hits.socials.facebook  = link;
    if (cls === 'instagram'  && !hits.socials.instagram) hits.socials.instagram = link;
    if (cls === 'twitter'    && !hits.socials.twitter)   hits.socials.twitter   = link;

    // Pull title/company/address from LinkedIn snippet.
    if (cls === 'linkedin') {
      const li = parseLinkedinSnippet(title, snippet);
      if (li.title    && !hits.title)    hits.title    = li.title;
      if (li.company  && !hits.company)  hits.company  = li.company;
      if (li.headline && !hits.headline) hits.headline = li.headline;
      if (li.address  && !hits.address)  hits.address  = li.address;
    }

    // First non-profile link is the most likely "personal/firm website".
    if (!hits.websiteUrl && !NON_WEBSITE.test(link)) {
      hits.websiteUrl = link;
    }

    // Phones / emails harvested from the title+snippet text.
    const text = `${title} ${snippet}`;
    hits.phones.push(...extractPhones(text));
    hits.emails.push(...extractEmails(text));
  }

  return hits;
}

// ─── Maps engine ──────────────────────────────────────────────────
// Returns the top-matching place card for `name + company`. Way richer
// than scraping local_results from web search.
function pickBestPlace(places, contact) {
  if (!places?.length) return null;
  // Prefer place whose title contains the company name or person's last name.
  const name = (contact.name || '').toLowerCase();
  const lastName = name.split(/\s+/).pop() || '';
  const company = (contact.company || '').toLowerCase();
  const ranked = places.map(p => {
    const t = (p.title || '').toLowerCase();
    let score = 0;
    if (company && t.includes(company.slice(0, 8))) score += 5;
    if (lastName && t.includes(lastName)) score += 3;
    if (p.rating) score += Math.min(2, p.rating - 3);
    if (p.reviews) score += Math.min(2, Math.log10(p.reviews + 1));
    return { p, score };
  }).sort((a, b) => b.score - a.score);
  return ranked[0]?.p || places[0];
}

async function mapsLookup(contact) {
  const queryParts = [contact.company, contact.address || contact.name].filter(Boolean);
  if (!queryParts.length) return null;
  const data = await searchMaps(queryParts.join(' '));
  if (!data) return null;
  const place = pickBestPlace(data.local_results || data.place_results ? [data.place_results].filter(Boolean) : data.local_results, contact);
  if (!place) return null;
  return {
    company: place.title || null,
    phone:   place.phone || null,
    address: place.address || null,
    websiteUrl: place.website || null,
    photoUrl: place.thumbnail || null,
    rating:   place.rating || null,
    reviews:  place.reviews || null,
    hours:    place.hours || null,
  };
}

// ─── Public lookup ────────────────────────────────────────────────
export async function lookup(contact) {
  if (!KEY) return { source: 'serpapi', skipped: 'no-key' };
  const name = contact.name;
  const typeTerm = contact.type === 'lawyer' ? 'attorney' : 'realtor';

  // Decide which queries to run. We always do `main`. We do `linkedin` only if
  // not already implied by a profile URL we capture in main. We do Maps if we
  // have a company hint. We do image search only if we still need a photo.
  const mainQuery = [name, contact.company, typeTerm].filter(Boolean).join(' ');
  const liQuery   = `site:linkedin.com/in "${name}" ${typeTerm}`;
  const imgQuery  = `${name} ${typeTerm} ${contact.company || ''} headshot`.trim();

  // Phase A — main + linkedin in parallel (cheap, always useful).
  const [main, liExtra] = await Promise.all([search(mainQuery), search(liQuery)]);

  const out = {
    source: 'serpapi',
    phone: null, email: null, company: null, title: null,
    linkedinUrl: null, websiteUrl: null, photoUrl: null,
    address: null, headline: null,
    socials: {}, profileUrls: {},
    rating: null, reviews: null,
  };
  if (!main) return out;

  // Parse main organic results.
  const org = parseOrganic(main.organic_results || []);
  if (org.phones[0])    out.phone       = org.phones[0];
  if (org.emails[0])    out.email       = org.emails[0];
  if (org.websiteUrl)   out.websiteUrl  = org.websiteUrl;
  if (org.title)        out.title       = org.title;
  if (org.company)      out.company     = org.company;
  if (org.address)      out.address     = org.address;
  if (org.headline)     out.headline    = org.headline;
  out.socials = { ...out.socials, ...org.socials };
  out.profileUrls = { ...out.profileUrls, ...org.profileUrls };
  if (org.profileUrls.linkedin) out.linkedinUrl = org.profileUrls.linkedin;

  // Knowledge Graph (rich entity card).
  const kg = main.knowledge_graph || {};
  if (kg.phone)   out.phone      = kg.phone || out.phone;
  if (kg.website) out.websiteUrl = kg.website || out.websiteUrl;
  if (kg.address) out.address    = kg.address || out.address;
  if (kg.image)   out.photoUrl   = kg.image || out.photoUrl;
  if (kg.title && !out.title) out.title = kg.title;

  // Answer box (e.g. featured snippet for businesses).
  const ab = main.answer_box || {};
  if (ab.phone && !out.phone) out.phone = ab.phone;
  if (ab.address && !out.address) out.address = ab.address;

  // LinkedIn snippet fallback (if main didn't surface a LinkedIn result).
  if (!out.linkedinUrl && liExtra) {
    const liOrg = parseOrganic(liExtra.organic_results || []);
    if (liOrg.profileUrls.linkedin) out.linkedinUrl = liOrg.profileUrls.linkedin;
    if (!out.title    && liOrg.title)    out.title    = liOrg.title;
    if (!out.company  && liOrg.company)  out.company  = liOrg.company;
    if (!out.address  && liOrg.address)  out.address  = liOrg.address;
    if (!out.headline && liOrg.headline) out.headline = liOrg.headline;
  }

  // Phase B — Maps engine (only if we have a company; otherwise too noisy).
  if (contact.company) {
    const place = await mapsLookup(contact);
    if (place) {
      out.phone       = out.phone       || place.phone;
      out.address     = out.address     || place.address;
      out.websiteUrl  = out.websiteUrl  || place.websiteUrl;
      out.photoUrl    = out.photoUrl    || place.photoUrl;
      out.company     = out.company     || place.company;
      out.rating      = place.rating;
      out.reviews     = place.reviews;
    }
  }

  // Phase C — image search ONLY if we still don't have a photo.
  if (!out.photoUrl) {
    const images = await search(imgQuery, { tbm: 'isch', num: '3' });
    if (images?.images_results?.[0]?.thumbnail) {
      out.photoUrl = images.images_results[0].thumbnail;
    }
  }

  return out;
}
