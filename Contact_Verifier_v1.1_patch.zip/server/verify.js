// server/verify.js — orchestrates all sources for a single contact.
//
// CHANGES vs v1:
//   1. Wires new emailGuess source (Hunter alternative).
//   2. Passes profileUrls from SerpAPI into website source for site-aware scrape.
//   3. Phase 2 runs hunter AND emailGuess in parallel — whichever has data wins
//      via aggregator agreement. (If user has both keys, hunter is canonical.)
//   4. website now returns an array of per-origin results; we spread it in.
import * as serpapi    from './sources/serpapi.js';
import * as hunter     from './sources/hunter.js';
import * as linkedin   from './sources/linkedin.js';
import * as pdl        from './sources/pdl.js';
import * as website    from './sources/website.js';
import * as gravatar   from './sources/gravatar.js';
import * as emailGuess from './sources/emailGuess.js';
import { aggregate } from './aggregator.js';
import { getCached, setCached } from './cache.js';
import { domainOf } from './util.js';

export function sourceStatus() {
  return {
    serpapi:    serpapi.available(),
    hunter:     hunter.available(),
    linkedin:   linkedin.available(),
    pdl:        pdl.available(),
    emailGuess: emailGuess.available(), // requires SERPAPI_KEY
    website:    true,
    gravatar:   true,
  };
}

export function sourceUsage() {
  return { serpapi: serpapi.getUsage?.() || null };
}

export async function verifyContact(contact, opts = {}) {
  const { skipCache = false } = opts;
  if (!skipCache) {
    const cached = getCached(contact);
    if (cached) return { ...cached, _fromCache: true };
  }

  const results = [];

  // Phase 1 — parallel high-signal generic sources.
  const [pdlRes, serpRes] = await Promise.all([
    pdl.lookup(contact),
    serpapi.lookup(contact),
  ]);
  results.push(pdlRes, serpRes);

  // Phase 2 — sources that depend on Phase 1 findings.
  const linkedinUrl = pdlRes?.linkedinUrl
                   || serpRes?.linkedinUrl
                   || serpRes?.profileUrls?.linkedin;
  const websiteUrl  = serpRes?.websiteUrl;
  const websiteDomain = domainOf(websiteUrl);
  const profileUrls = { ...(pdlRes?.profileUrls || {}), ...(serpRes?.profileUrls || {}) };

  const [liRes, huntRes, guessRes, webResArr] = await Promise.all([
    linkedin.lookup(linkedinUrl),
    hunter.lookup(contact, { websiteDomain }),
    emailGuess.lookup(contact, { websiteDomain }),
    website.lookup(contact, { websiteUrl, profileUrls }),
  ]);
  results.push(liRes, huntRes, guessRes, ...(Array.isArray(webResArr) ? webResArr : [webResArr]));

  // Phase 3 — gravatar via any email we now know.
  const knownEmail = results.find(r => r?.email)?.email || contact.email;
  const gravRes = await gravatar.lookup(knownEmail);
  results.push(gravRes);

  const merged = aggregate(contact, results);
  setCached(contact, merged);
  return merged;
}
